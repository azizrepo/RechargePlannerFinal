package com.cts;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class RechargePlannerApplicationSeleniumTest {
	WebDriver driver;

	@BeforeTest
	public void beforeTest() {
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
        capabilities.setCapability("marionette", true);
        driver = new FirefoxDriver(capabilities);
		driver.get("http://localhost:9029");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("hello");
	}

	@Test(priority = 1)
	public void checkWhetherThePlanIsNotExpired() {
		WebElement name = driver.findElement(By.id("name"));
		WebElement mobileNo = driver.findElement(By.id("mobileNo"));
		WebElement previousRechargeDate = driver.findElement(By.id("re_date"));
		WebElement selectedPackage = driver.findElement(By.id("plan"));
		WebElement submitButton = driver.findElement(By.id("submit"));
		name.sendKeys("ksrao");
		mobileNo.sendKeys("9505962345");
		previousRechargeDate.clear();
		previousRechargeDate.sendKeys("2020-04-10");
		Select previousPackageSelected = new Select(selectedPackage);
		previousPackageSelected.selectByVisibleText("Airtel Rs.399 30 Days Recharge Plan");
		submitButton.click();
		WebElement h1 = driver.findElement(By.id("msg"));
		String msg = h1.getText().trim();
		assertEquals(msg, "Your mobile validity is not expired");
		driver.navigate().back();

	}

	@Test(priority = 2)
	public void testWhetherUserNameIsValid() {
		WebElement name = driver.findElement(By.id("name"));
		WebElement mobileNo = driver.findElement(By.id("mobileNo"));
		WebElement previousRechargeDate = driver.findElement(By.id("re_date"));
		WebElement selectedPackage = driver.findElement(By.id("plan"));
		name.clear();
		name.sendKeys(" ");
		mobileNo.sendKeys("9505962345");
		previousRechargeDate.clear();
		previousRechargeDate.sendKeys("2020-03-10");
		Select previousPackageSelected = new Select(selectedPackage);
		previousPackageSelected.selectByVisibleText("Airtel Rs.399 30 Days Recharge Plan");
		WebElement submitButton = driver.findElement(By.id("submit"));
		submitButton.click();
		WebElement nameError = driver.findElement(By.id("nameError"));
		String nameErrorMsg = nameError.getText().trim();
		assertEquals(nameErrorMsg, "name is required");
		driver.navigate().back();

	}

	@Test(priority = 3)
	public void testWhetherMobileNoIsValid() {
		WebElement name = driver.findElement(By.id("name"));
		WebElement mobileNo = driver.findElement(By.id("mobileNo"));
		WebElement previousRechargeDate = driver.findElement(By.id("re_date"));
		WebElement selectedPackage = driver.findElement(By.id("plan"));
		name.sendKeys("ksrao");
		mobileNo.clear();
		mobileNo.sendKeys(" ");
		previousRechargeDate.clear();
		previousRechargeDate.sendKeys("2020-03-10");
		Select previousPackageSelected = new Select(selectedPackage);
		previousPackageSelected.selectByVisibleText("Airtel Rs.399 30 Days Recharge Plan");
		WebElement submitButton = driver.findElement(By.id("submit"));
		submitButton.click();
		WebElement mobileNoError = driver.findElement(By.id("mobileNoError"));
		String mobileNoErrorMsg = mobileNoError.getText().trim();
		assertEquals(mobileNoErrorMsg, "mobile no is required");
		driver.navigate().back();
	}

	@Test(priority = 4)
	public void testInvalidRechargeDateException() {
		WebElement name = driver.findElement(By.id("name"));
		WebElement mobileNo = driver.findElement(By.id("mobileNo"));
		WebElement previousRechargeDate = driver.findElement(By.id("re_date"));
		WebElement selectedPackage = driver.findElement(By.id("plan"));
		WebElement submitButton = driver.findElement(By.id("submit"));
		name.sendKeys("ksrao");
		mobileNo.sendKeys("9505962345");
		previousRechargeDate.clear();
		previousRechargeDate.sendKeys("2020-04-19");
		Select previousPackageSelected = new Select(selectedPackage);
		previousPackageSelected.selectByVisibleText("Airtel Rs.399 30 Days Recharge Plan");
		submitButton.click();
		WebElement p = driver.findElement(By.id("exceptionMsg"));
		String exceptionMsg = p.getText().trim();
		assertEquals(exceptionMsg, "You selected invalid date Please select valid date");
		driver.navigate().back();
	}

	@Test(priority = 5)
	public void testWhetherLanguageIsEnglish() {
		WebElement anchor1 = driver.findElement(By.xpath("/html/body/div[1]/a[1]"));
		anchor1.click();
		anchor1 = driver.findElement(By.xpath("/html/body/div[1]/a[1]"));
		WebElement anchor2 = driver.findElement(By.xpath("/html/body/div[1]/a[2]"));
		WebElement anchor3 = driver.findElement(By.xpath("/html/body/div[1]/a[3]"));
		WebElement nameLabel = driver.findElement(By.id("namelbl"));
		WebElement mobileNoLabel = driver.findElement(By.id("mobileNoLbl"));
		WebElement prevoiusRechargeLabel = driver.findElement(By.id("previousRechargeLbl"));
		WebElement previousPackageLabel = driver.findElement(By.id("previousPackageLbl"));
		WebElement submitButton = driver.findElement(By.id("submit"));
		String nameLabelTextExpected = nameLabel.getText().trim();
		String mobileNoLabelTextExpected = mobileNoLabel.getText().trim();
		String previousRechargeLabelTextExpected = prevoiusRechargeLabel.getText().trim();
		String preciousPackageLabelTextExpected = previousPackageLabel.getText().toString();
		String submitButtonTextExpected = submitButton.getText().trim();
		String anchorTextEnglish = anchor1.getText().trim();
		String anchorTextGerman = anchor2.getText().trim();
		String anchorTextFrench = anchor3.getText().trim();
		assertEquals(anchorTextEnglish, "English");
		assertEquals(anchorTextGerman, "German");
		assertEquals(anchorTextFrench, "French");
		assertEquals(nameLabelTextExpected, "Enter your name");
		assertEquals(mobileNoLabelTextExpected, "Enter your mobileno");
		assertEquals(previousRechargeLabelTextExpected, "your previousrechargedate");
		assertEquals(preciousPackageLabelTextExpected, "Your previous package");
		assertEquals(submitButtonTextExpected, "checkStatus");
		driver.navigate().back();
	}

	@Test(priority = 6)
	public void testWhetherLanguageIsGerman() {
		WebElement anchor2 = driver.findElement(By.xpath("/html/body/div[1]/a[2]"));
		anchor2.click();
		WebElement anchor1 = driver.findElement(By.xpath("/html/body/div[1]/a[1]"));
		anchor2 = driver.findElement(By.xpath("/html/body/div[1]/a[2]"));
		WebElement nameLabel = driver.findElement(By.id("namelbl"));
		WebElement mobileNoLabel = driver.findElement(By.id("mobileNoLbl"));
		WebElement prevoiusRechargeLabel = driver.findElement(By.id("previousRechargeLbl"));
		WebElement previousPackageLabel = driver.findElement(By.id("previousPackageLbl"));
		String nameLabelTextExpected = nameLabel.getText().trim();
		String mobileNoLabelTextExpected = mobileNoLabel.getText().trim();
		String previousRechargeLabelTextExpected = prevoiusRechargeLabel.getText().trim();
		String preciousPackageLabelTextExpected = previousPackageLabel.getText().toString();
		String anchorTextEnglish = anchor1.getText().trim();
		String anchorTextGerman = anchor2.getText().trim();
		assertEquals(anchorTextEnglish, "Englisch");
		assertEquals(anchorTextGerman, "Deutsche");
		assertEquals(nameLabelTextExpected, "Gib deinen Namen ein");
		assertEquals(mobileNoLabelTextExpected, "Geben Sie Ihr mobilo ein");
		assertEquals(previousRechargeLabelTextExpected, "Ihr vorheriges aufgeladenes Datum");
		assertEquals(preciousPackageLabelTextExpected, "Ihr vorheriges Paket");
		driver.navigate().back();
	}

	@Test(priority = 7)
	public void testWhetherLanguageIsFrench() {

		WebElement anchor3 = driver.findElement(By.xpath("/html/body/div[1]/a[3]"));
		anchor3.click();
		WebElement anchor1 = driver.findElement(By.xpath("/html/body/div[1]/a[1]"));
		WebElement anchor2 = driver.findElement(By.xpath("/html/body/div[1]/a[2]"));
		anchor3 = driver.findElement(By.xpath("/html/body/div[1]/a[3]"));
		WebElement nameLabel = driver.findElement(By.id("namelbl"));
		WebElement mobileNoLabel = driver.findElement(By.id("mobileNoLbl"));
		WebElement prevoiusRechargeLabel = driver.findElement(By.id("previousRechargeLbl"));
		WebElement previousPackageLabel = driver.findElement(By.id("previousPackageLbl"));
		String nameLabelTextExpected = nameLabel.getText().trim();
		String mobileNoLabelTextExpected = mobileNoLabel.getText().trim();
		String previousRechargeLabelTextExpected = prevoiusRechargeLabel.getText().trim();
		String preciousPackageLabelTextExpected = previousPackageLabel.getText().toString();
		String anchorTextEnglish = anchor1.getText().trim();
		String anchorTextGerman = anchor2.getText().trim();
		assertEquals(anchorTextEnglish, "Anglaise");
		assertEquals(anchorTextGerman, "Allemande");
		assertEquals(nameLabelTextExpected, "Entrez votre nom");
		assertEquals(mobileNoLabelTextExpected, "Entrez votre mobile non");
		assertEquals(previousRechargeLabelTextExpected, "Votre date de recharge pr?c?dente");
		assertEquals(preciousPackageLabelTextExpected, "Votre package s?lectionn? pr?c?dent");
		driver.navigate().back();
	}

	@Test(priority = 8)
	public void testWhetherAllThePlansAreListedBasedOnPreviosPackageCarrierType() {
		int carrierCount = 0;
		int rowCount = 0;
		WebElement name = driver.findElement(By.id("name"));
		WebElement mobileNo = driver.findElement(By.id("mobileNo"));
		WebElement previousRechargeDate = driver.findElement(By.id("re_date"));
		WebElement selectedPackage = driver.findElement(By.id("plan"));
		WebElement submitButton = driver.findElement(By.id("submit"));
		name.sendKeys("ksrao");
		mobileNo.sendKeys("9505962345");
		previousRechargeDate.clear();
		previousRechargeDate.sendKeys("2020-01-10");
		Select previousPackageSelected = new Select(selectedPackage);
		previousPackageSelected.selectByVisibleText("Airtel Rs.399 30 Days Recharge Plan");
		submitButton.click();
		WebElement table = driver.findElement(By.xpath("//*[@id=\"content\"]/table"));
		int numOfRow = table.findElements(By.tagName("tr")).size();
		String first_part = "//*[@id=\"content\"]/table/tbody/tr[";
		String second_part = "]/td[";
		String third_part = "]";
		int j = 3;
		List<String> carrierList = new ArrayList<>();
		for (int i = 2; i <= numOfRow; i++) {
			rowCount++;
			String final_xpath = first_part + i + second_part + j + third_part;
			String carrier = driver.findElement(By.xpath(final_xpath)).getText();
			carrierList.add(carrier);
		}
		for (String carrier : carrierList) {
			if (carrier.equalsIgnoreCase("airtel")) {
				carrierCount++;
			}
		}
		assertEquals(rowCount, carrierCount);
		driver.navigate().back();
	}

	@Test(priority = 9)
	public void testWhetherPlanListIsLoaded() {

		WebElement name = driver.findElement(By.id("name"));
		WebElement mobileNo = driver.findElement(By.id("mobileNo"));
		WebElement previousRechargeDate = driver.findElement(By.id("re_date"));
		WebElement selectedPackage = driver.findElement(By.id("plan"));
		WebElement submitButton = driver.findElement(By.id("submit"));
		name.clear();
		name.sendKeys("ksrao");
		mobileNo.clear();
		mobileNo.sendKeys("9505962345");
		previousRechargeDate.clear();
		previousRechargeDate.sendKeys("2020-01-10");
		Select previousPackageSelected = new Select(selectedPackage);
		previousPackageSelected.selectByVisibleText("Airtel Rs.399 30 Days Recharge Plan");
		submitButton.click();
		WebElement headingElement = driver.findElement(By.id("plan-list"));
		String headingText = headingElement.getText().toString();
		assertEquals(headingText, "List Of Available Packages");
		driver.navigate().back();
	}
	@Test(priority = 10)
	@Ignore
	public void testWhetherSelectedPlanDetailsAreDisplayedInDetailsPage() {
		WebElement name = driver.findElement(By.id("name"));
		WebElement mobileNo = driver.findElement(By.id("mobileNo"));
		WebElement previousRechargeDate = driver.findElement(By.id("re_date"));
		WebElement selectedPackage = driver.findElement(By.id("plan"));
		WebElement submitButton = driver.findElement(By.id("submit"));
		name.clear();
		name.sendKeys("ksrao");
		mobileNo.clear();
		mobileNo.sendKeys("9505962345");
		previousRechargeDate.clear();
		previousRechargeDate.sendKeys("2020-01-10");
		Select previousPackageSelected = new Select(selectedPackage);
		previousPackageSelected.selectByVisibleText("Airtel Rs.399 30 Days Recharge Plan");
		submitButton.click();
		WebElement firstPlan=driver.findElement(By.xpath("//a[@id=\"1\"]"));
		firstPlan.click();
		WebElement planName=driver.findElement(By.id("pname"));
		assertEquals("The plan Name is : Airtel Rs.399 30 Days Recharge Plan", planName.getText().trim());
		
	}
	@AfterTest
	public void afterTest() {
		System.out.println("hi");
		driver.close();
	}
}
