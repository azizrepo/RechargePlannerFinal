package com.cts.controllers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cts.model.RechargePackage;
import com.cts.service.RechargeService;

class RechargeControllerTest {
	@Mock
	RechargeService rechargeService;
	RechargeController controller=null;

	MockMvc mockMvc;

	@BeforeTest
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		controller = new RechargeController(rechargeService);
		System.out.println(controller);
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}
	//this test will check whether the home page is loaded
	@Test
	public void testShowHomePage() throws Exception {
		 mockMvc.perform(get("/"))
         .andExpect(status().isOk())
         .andExpect(view().name("index"));
	}
	//this test check whether rechargePlan status is active
	@Test
	public void testCheckStatusActive() throws Exception {
		boolean b=true;
        when(rechargeService.checkStatus(any())).thenReturn(b);
        mockMvc.perform(post("/check")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "ksrao")
                .param("mobileNo", "9505962345")
                .param("previousRechargeDate","2010-03-15")
                .param("previousSelectedPackage", "some package")
        		)
                .andExpect(status().isOk())
                .andExpect(view().name("index"));
		
	}
	//this test checks whether the customer form validation fails
	@Test
    public void testPostCustomerDetailsFormValidationFail() throws Exception {
        boolean b=false;

        when(rechargeService.checkStatus(any())).thenReturn(b);

        mockMvc.perform(post("/check")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", " ")
                .param("mobileNo", " ")
                .param("previousRechargeDate","2010-03-15")
                .param("previousSelectedPackage", "some package")
        )
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("customerDetails"))
                .andExpect(view().name("index"));
    }
	//this test will check whether the details page is loaded
	@Test
	public void testShowDetailPage() throws Exception {
		RechargePackage rechargePackage = new RechargePackage();
        rechargePackage.setId(1);
        when(rechargeService.getPackage(1)).thenReturn(rechargePackage);
        mockMvc.perform(get("/detail/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("details"))
                .andExpect(model().attributeExists("pack"));
	}

}
